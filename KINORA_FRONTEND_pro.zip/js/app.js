(function () {
  "use strict";

  const S = window.KinoraStore;
  const $ = (id) => document.getElementById(id);

  const els = {
    movieGrid: $("movieGrid"), seriesGrid: $("seriesGrid"), featuredGrid: $("featuredGrid"),
    featuredSection: $("featured"), search: $("searchInput"), heroStats: $("heroStats"),
    loginModal: $("loginModal"), movieModal: $("movieModal"), movieBody: $("movieModalBody"),
    toast: $("toast"),
  };

  const state = { all: [], category: "all", query: "" };
  let toastTimer = null;
  let lastFocus = null;

  /* ---------- Rendering ---------- */
  function cardHtml(m) {
    const bg = m.posterUrl ? ` style="background-image:url('${S.esc(m.posterUrl)}')"` : "";
    const cls = m.posterUrl ? "poster has-image" : `poster poster-${m.poster}`;
    return `<article class="movie-card" tabindex="0" role="button" data-id="${m.id}" aria-label="${S.esc(m.title)} haqida">
      <div class="${cls}"${bg}>
        ${m.rating ? `<span class="rating-badge">★ ${m.rating.toFixed(1)}</span>` : ""}
        <span class="poster-title">${S.esc(m.title)}</span>
      </div>
      <div class="movie-info"><strong>${S.esc(m.title)}</strong><small>${S.esc(S.GENRE_LABELS[m.genre])} · ${m.year}</small></div>
    </article>`;
  }

  const emptyHtml = (text) => `<p class="empty">${text}</p>`;

  function render() {
    const published = state.all.filter((m) => m.status === "published");
    const q = state.query.toLowerCase();

    const movies = published.filter((m) => m.type === "movie").filter((m) =>
      (state.category === "all" || m.genre === state.category) &&
      (!q || m.title.toLowerCase().includes(q) || S.GENRE_LABELS[m.genre].toLowerCase().includes(q) || m.genre.toLowerCase().includes(q)));
    els.movieGrid.innerHTML = movies.length ? movies.map(cardHtml).join("") : emptyHtml("Hech narsa topilmadi.");

    const series = published.filter((m) => m.type === "series");
    els.seriesGrid.innerHTML = series.length ? series.map(cardHtml).join("") : emptyHtml("Hozircha seriallar yo‘q.");

    const featured = published.filter((m) => m.featured);
    els.featuredSection.hidden = !featured.length;
    els.featuredGrid.innerHTML = featured.map(cardHtml).join("");

    const mCount = published.filter((m) => m.type === "movie").length;
    els.heroStats.innerHTML =
      `<div><dt>Filmlar</dt><dd>${mCount}</dd></div><div><dt>Seriallar</dt><dd>${series.length}</dd></div><div><dt>Sifat</dt><dd>HD</dd></div>`;
  }

  /* ---------- Modals ---------- */
  function openModal(modal) {
    lastFocus = document.activeElement;
    modal.classList.remove("hidden");
    document.body.classList.add("no-scroll");
    const target = modal.querySelector("input, button:not([data-close])") || modal.querySelector("[data-close]");
    if (target) target.focus();
  }

  function closeModal(modal) {
    modal.classList.add("hidden");
    if (document.querySelectorAll(".modal:not(.hidden)").length === 0) document.body.classList.remove("no-scroll");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("click", (e) => {
      if (e.target === modal || e.target.closest("[data-close]")) closeModal(modal);
    });
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") document.querySelectorAll(".modal:not(.hidden)").forEach(closeModal);
  });

  function openMovie(id) {
    const m = state.all.find((x) => x.id === id);
    if (!m) return;
    const bg = m.posterUrl ? ` style="background-image:url('${S.esc(m.posterUrl)}')"` : "";
    const cls = m.posterUrl ? "poster has-image" : `poster poster-${m.poster}`;
    els.movieBody.innerHTML = `
      <div class="movie-detail">
        <div class="${cls}"${bg}><span class="poster-title">${S.esc(m.title)}</span></div>
        <div>
          <div class="eyebrow">${m.type === "series" ? "SERIAL" : "FILM"}</div>
          <h2 id="movieModalTitle">${S.esc(m.title)}</h2>
          <ul class="meta">
            <li>${S.esc(S.GENRE_LABELS[m.genre])}</li><li>${m.year}</li>
            ${m.duration ? `<li>${S.esc(m.duration)}</li>` : ""}
            ${m.rating ? `<li>★ ${m.rating.toFixed(1)}</li>` : ""}
          </ul>
          <p>${S.esc(m.description || "Tavsif tez orada qo‘shiladi.")}</p>
          <button class="primary-button" type="button" id="playButton">▶ Tomosha qilish</button>
        </div>
      </div>`;
    $("playButton").onclick = () => toast("Video player keyingi modulda ulanadi.");
    openModal(els.movieModal);
  }

  function onCardActivate(e) {
    const card = e.target.closest(".movie-card");
    if (!card) return;
    if (e.type === "keydown" && e.key !== "Enter" && e.key !== " ") return;
    e.preventDefault();
    openMovie(+card.dataset.id);
  }
  [els.movieGrid, els.seriesGrid, els.featuredGrid].forEach((g) => {
    g.addEventListener("click", onCardActivate);
    g.addEventListener("keydown", onCardActivate);
  });

  /* ---------- Toast ---------- */
  function toast(text) {
    els.toast.textContent = text;
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove("show"), 3200);
  }

  /* ---------- Filters ---------- */
  let debounce = null;
  els.search.addEventListener("input", () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => { state.query = els.search.value.trim(); render(); }, 120);
  });

  document.querySelectorAll(".category").forEach((btn) => btn.addEventListener("click", () => {
    document.querySelectorAll(".category").forEach((x) => x.classList.remove("active"));
    btn.classList.add("active");
    state.category = btn.dataset.category;
    render();
  }));

  /* ---------- Navigation buttons ---------- */
  const toMovies = () => $("movies").scrollIntoView({ behavior: "smooth" });
  $("catalogButton").onclick = toMovies;
  $("watchButton").onclick = toMovies;
  $("searchButton").onclick = () => { toMovies(); setTimeout(() => els.search.focus(), 350); };

  /* ---------- User login (demo) ---------- */
  $("loginButton").onclick = () => openModal(els.loginModal);
  $("registerButton").onclick = () => toast("Ro‘yxatdan o‘tish backend modulida ulanadi.");
  $("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const email = $("emailInput").value.trim();
    const pass = $("passwordInput").value;
    const err = $("loginError");
    if (!/^\S+@\S+\.\S+$/.test(email)) { err.textContent = "To‘g‘ri email kiriting."; return; }
    if (pass.length < 6) { err.textContent = "Parol kamida 6 ta belgidan iborat bo‘lsin."; return; }
    err.textContent = "";
    closeModal(els.loginModal);
    $("loginForm").reset();
    toast("Frontend demo: kirish muvaffaqiyatli.");
  });

  /* ---------- Navbar shadow on scroll & live updates from admin ---------- */
  const nav = document.querySelector(".navbar");
  const onScroll = () => nav.classList.toggle("scrolled", window.scrollY > 8);
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  window.addEventListener("storage", (e) => {
    if (e.key === "kinora.catalog.v1") { state.all = S.load(); render(); }
  });

  state.all = S.load();
  render();
})();
