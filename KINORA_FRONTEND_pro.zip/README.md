# KINORA — Frontend

Qonuniy striming platformasi (statik frontend).

## Ishga tushirish
`index.html` ni brauzerda oching, yoki: `python3 -m http.server 8000`

## Tuzilma
- `index.html` — foydalanuvchi sayti
- `admin.html` — admin panel (login sahifasi bilan)
- `js/store.js` — katalog saqlash (localStorage) va admin autentifikatsiya
- `js/app.js`, `js/admin.js` — sayt va admin logikasi
- `css/main.css`, `css/admin.css` — uslublar
- `data/movies.json` — boshlang‘ich katalog namunasi

## Admin panel
`/admin.html` — katalogni boshqarish: qo‘shish, tahrirlash, o‘chirish, nashr/qoralama, tanlanganlar, qidiruv/filtr, JSON eksport/import.

## Xavfsizlik eslatmasi
Bu faqat frontend demo: login/parol tekshiruvi brauzerda bajariladi (hash ko‘rinishida), ma’lumotlar localStorage'da saqlanadi.
Haqiqiy loyihada autentifikatsiya, sessiyalar va ma’lumotlar bazasi backendda bo‘lishi shart.
