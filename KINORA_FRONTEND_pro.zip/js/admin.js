(function () {
  "use strict";

  const S = window.KinoraStore;
  const $ = (id) => document.getElementById(id);

  let items = [];
  let pendingDelete = null;
  let toastTimer = null;
  let lastFocus = null;

  /* ---------- Helpers ---------- */
  function toast(text) {
    const t = $("toast");
    t.textContent = text;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 3000);
  }

  function persist(message) {
    if (!S.save(items)) { toast("Saqlab bo‘lmadi: brauzer xotirasi mavjud emas."); return; }
    render();
    if (message) toast(message);
  }

  function openModal(m) {
    lastFocus = document.activeElement;
    m.classList.remove("hidden");
    document.body.classList.add("no-scroll");
    const f = m.querySelector("input:not([type=hidden]), button:not([data-close])");
    if (f) f.focus();
  }
  function closeModal(m) {
    m.classList.add("hidden");
    if (!document.querySelector(".modal:not(.hidden)")) document.body.classList.remove("no-scroll");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  document.querySelectorAll(".modal").forEach((m) =>
    m.addEventListener("click", (e) => { if (e.target === m || e.target.closest("[data-close]")) closeModal(m); }));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") document.querySelectorAll(".modal:not(.hidden)").forEach(closeModal);
  });

  /* ---------- Auth ---------- */
  function showApp() {
    const ok = S.isAdmin();
    $("loginScreen").classList.toggle("hidden", ok);
    $("dashboard").classList.toggle("hidden", !ok);
    if (ok) { items = S.load(); render(); }
    else $("adminUser").focus();
  }

  $("togglePass").onclick = () => {
    const p = $("adminPass");
    const show = p.type === "password";
    p.type = show ? "text" : "password";
    $("togglePass").textContent = show ? "Yashir" : "Ko‘rsat";
  };

  $("adminLoginForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("adminError");
    const btn = $("adminSubmit");
    const user = $("adminUser").value;
    const pass = $("adminPass").value;
    if (!user.trim() || !pass) { err.textContent = "Login va parolni kiriting."; return; }
    btn.disabled = true;
    try {
      const r = await S.adminLogin(user, pass);
      if (r.ok) { err.textContent = ""; $("adminPass").value = ""; showApp(); return; }
      if (r.error) err.textContent = r.error;
      else if (r.locked) err.textContent = `Juda ko‘p urinish. ${r.locked} soniyadan so‘ng qayta urinib ko‘ring.`;
      else err.textContent = `Login yoki parol noto‘g‘ri. Qolgan urinishlar: ${r.left}.`;
    } finally { btn.disabled = false; }
  });

  $("logoutButton").onclick = () => { S.adminLogout(); showApp(); };

  // Re-check expiry every minute
  setInterval(() => { if (!S.isAdmin() && $("loginScreen").classList.contains("hidden")) showApp(); }, 60000);

  /* ---------- Rendering ---------- */
  const typeLabel = (t) => (t === "series" ? "Serial" : "Film");

  function renderStats() {
    const pub = items.filter((m) => m.status === "published").length;
    const rated = items.filter((m) => m.rating > 0);
    const avg = rated.length ? (rated.reduce((s, m) => s + m.rating, 0) / rated.length).toFixed(1) : "—";
    const cards = [
      ["Jami kontent", items.length],
      ["Filmlar", items.filter((m) => m.type === "movie").length],
      ["Seriallar", items.filter((m) => m.type === "series").length],
      ["Nashr etilgan", pub],
      ["Qoralama", items.length - pub],
      ["O‘rtacha reyting", avg],
    ];
    $("overview").innerHTML = cards.map(([l, v]) => `<div class="stat"><span>${l}</span><strong>${v}</strong></div>`).join("");
  }

  function filtered() {
    const q = $("adminSearch").value.trim().toLowerCase();
    const type = $("filterType").value;
    const status = $("filterStatus").value;
    return items.filter((m) =>
      (!q || m.title.toLowerCase().includes(q)) &&
      (type === "all" || m.type === type) &&
      (status === "all" || m.status === status));
  }

  function render() {
    renderStats();
    const list = filtered();
    $("tableBody").innerHTML = list.length ? list.map((m) => {
      const thumb = m.posterUrl
        ? `<span class="thumb" style="background-image:url('${S.esc(m.posterUrl)}')"></span>`
        : `<span class="thumb poster-${m.poster}"></span>`;
      return `<tr>
        <td><div class="cell-title">${thumb}<span>${S.esc(m.title)}${m.featured ? '<span class="star" title="Tanlangan">★</span>' : ""}</span></div></td>
        <td>${typeLabel(m.type)}</td>
        <td>${S.esc(S.GENRE_LABELS[m.genre])}</td>
        <td>${m.year}</td>
        <td>${m.rating ? m.rating.toFixed(1) : "—"}</td>
        <td><span class="pill ${m.status === "published" ? "ok" : "draft"}">${m.status === "published" ? "Nashr etilgan" : "Qoralama"}</span></td>
        <td class="right"><div class="row-actions">
          <button class="ghost-btn" data-act="toggle" data-id="${m.id}">${m.status === "published" ? "Yashirish" : "Nashr"}</button>
          <button class="ghost-btn" data-act="edit" data-id="${m.id}">Tahrirlash</button>
          <button class="ghost-btn danger" data-act="delete" data-id="${m.id}">O‘chirish</button>
        </div></td></tr>`;
    }).join("") : `<tr><td colspan="7" class="empty-row">Hech narsa topilmadi.</td></tr>`;
    $("countLabel").textContent = `${list.length} / ${items.length} ta yozuv`;
  }

  ["adminSearch", "filterType", "filterStatus"].forEach((id) => $(id).addEventListener("input", render));

  /* ---------- Table actions ---------- */
  $("tableBody").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const m = items.find((x) => x.id === +btn.dataset.id);
    if (!m) return;
    if (btn.dataset.act === "edit") openForm(m);
    if (btn.dataset.act === "toggle") {
      m.status = m.status === "published" ? "draft" : "published";
      persist(m.status === "published" ? "Nashr etildi." : "Qoralamaga o‘tkazildi.");
    }
    if (btn.dataset.act === "delete") {
      pendingDelete = m.id;
      $("confirmText").textContent = `“${m.title}” butunlay o‘chiriladi. Bu amalni qaytarib bo‘lmaydi.`;
      openModal($("confirmModal"));
    }
  });

  $("confirmYes").onclick = () => {
    if (pendingDelete == null) return;
    items = items.filter((m) => m.id !== pendingDelete);
    pendingDelete = null;
    closeModal($("confirmModal"));
    persist("Kontent o‘chirildi.");
  };

  /* ---------- Form ---------- */
  $("fGenre").innerHTML = S.GENRES.map((g) => `<option value="${g}">${S.GENRE_LABELS[g]}</option>`).join("");

  function openForm(m) {
    const isNew = !m;
    $("editTitle").textContent = isNew ? "Yangi kontent" : "Tahrirlash";
    const d = m || { id: "", title: "", type: "movie", genre: "Drama", year: new Date().getFullYear(), rating: "", duration: "", poster: 1, posterUrl: "", description: "", status: "published", featured: false };
    $("fId").value = d.id;
    $("fTitle").value = d.title;
    $("fType").value = d.type;
    $("fGenre").value = d.genre;
    $("fYear").value = d.year;
    $("fRating").value = d.rating || "";
    $("fDuration").value = d.duration;
    $("fPoster").value = d.poster;
    $("fPosterUrl").value = d.posterUrl;
    $("fDesc").value = d.description;
    $("fStatus").value = d.status;
    $("fFeatured").checked = d.featured;
    $("editError").textContent = "";
    openModal($("editModal"));
  }

  $("addButton").onclick = () => openForm(null);

  $("editForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const err = $("editError");
    const title = $("fTitle").value.trim();
    const rating = $("fRating").value === "" ? 0 : parseFloat($("fRating").value);
    const year = parseInt($("fYear").value, 10);
    const url = $("fPosterUrl").value.trim();

    if (!title) { err.textContent = "Nomini kiriting."; return; }
    if (!(year >= 1900 && year <= 2100)) { err.textContent = "Yil 1900–2100 oralig‘ida bo‘lsin."; return; }
    if (!(rating >= 0 && rating <= 10)) { err.textContent = "Reyting 0 dan 10 gacha bo‘lsin."; return; }
    if (url && !S.cleanUrl(url)) { err.textContent = "Poster URL http:// yoki https:// bilan boshlansin."; return; }

    const id = $("fId").value ? +$("fId").value : S.nextId(items);
    const rec = S.normalize({
      id, title, year, rating, posterUrl: url,
      type: $("fType").value, genre: $("fGenre").value, duration: $("fDuration").value,
      poster: $("fPoster").value, description: $("fDesc").value, status: $("fStatus").value,
      featured: $("fFeatured").checked,
    }, id);

    const idx = items.findIndex((m) => m.id === id);
    if (idx >= 0) items[idx] = rec; else items.push(rec);
    closeModal($("editModal"));
    persist(idx >= 0 ? "O‘zgarishlar saqlandi." : "Yangi kontent qo‘shildi.");
  });

  /* ---------- Export / import / reset ---------- */
  $("exportButton").onclick = () => {
    const blob = new Blob([JSON.stringify({ movies: items }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "kinora-catalog.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };

  $("importButton").onclick = () => $("importFile").click();
  $("importFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    if (file.size > 1024 * 1024) { toast("Fayl juda katta (maks. 1 MB)."); return; }
    try {
      const data = JSON.parse(await file.text());
      const arr = Array.isArray(data) ? data : data.movies;
      if (!Array.isArray(arr)) throw new Error("format");
      const seen = new Set();
      const clean = arr.map((m, i) => S.normalize(m, i + 1)).filter((m) => {
        if (!m.title || seen.has(m.id)) return false;
        seen.add(m.id);
        return true;
      });
      if (!clean.length) throw new Error("empty");
      items = clean;
      persist(`${clean.length} ta yozuv import qilindi.`);
    } catch (err) {
      toast("Import xatosi: JSON formati noto‘g‘ri.");
    }
  });

  $("resetButton").onclick = () => {
    if (!confirm("Barcha o‘zgarishlar o‘chirilib, boshlang‘ich katalog tiklansinmi?")) return;
    items = S.reset();
    S.save(items);
    render();
    toast("Boshlang‘ich katalog tiklandi.");
  };

  showApp();
})();
