/* KINORA — shared data store & auth helpers (frontend demo layer).
 * Real production auth and storage must live on a backend. */
(function (global) {
  "use strict";

  const STORAGE_KEY = "kinora.catalog.v1";
  const SESSION_KEY = "kinora.admin.session";
  const LOCK_KEY = "kinora.admin.lock";
  const SESSION_TTL = 2 * 60 * 60 * 1000; // 2 hours
  const MAX_ATTEMPTS = 5;
  const LOCK_MS = 60 * 1000;

  // SHA-256 (salted) of the admin credentials — plain text is never stored in code.
  const ADMIN = {
    user: "763a4660e9753019e099ff72d357563fc761669d249ea3f6647b69b92b89b07c",
    pass: "c56f7333c30da6a16d04ba4a5c9dd9b47624846e68c94243f5571df26e77c9a8",
  };

  const GENRES = ["Drama", "Action", "Comedy", "Sci-Fi"];
  const GENRE_LABELS = { Drama: "Drama", Action: "Action", Comedy: "Komediya", "Sci-Fi": "Fantastika" };

  const DEFAULTS = [
    { id: 1, title: "ORIGIN", genre: "Drama", year: 2026, type: "movie", poster: 1, duration: "1s 54d", rating: 8.4, status: "published", featured: true, description: "Yo‘qotishdan keyin o‘z yo‘lini topishga urinayotgan odam haqidagi chuqur drama." },
    { id: 2, title: "THE VOYAGE", genre: "Action", year: 2026, type: "movie", poster: 2, duration: "2s 07d", rating: 7.9, status: "published", featured: false, description: "Okean o‘rtasidagi xavfli ekspeditsiya va omon qolish uchun kurash." },
    { id: 3, title: "AFTER RAIN", genre: "Drama", year: 2025, type: "movie", poster: 3, duration: "1s 41d", rating: 8.1, status: "published", featured: false, description: "Yomg‘irdan keyin boshlangan yangi hayot haqida sokin va samimiy hikoya." },
    { id: 4, title: "NIGHT SHIFT", genre: "Action", year: 2026, type: "movie", poster: 4, duration: "1s 48d", rating: 7.5, status: "published", featured: false, description: "Tungi smenada boshlanadigan bir kechalik shiddatli voqealar." },
    { id: 5, title: "GREEN LINE", genre: "Comedy", year: 2026, type: "movie", poster: 5, duration: "1s 32d", rating: 7.2, status: "published", featured: false, description: "Shahar metrosidagi kulgili tasodiflar va kutilmagan uchrashuvlar." },
    { id: 6, title: "ORBIT", genre: "Sci-Fi", year: 2026, type: "movie", poster: 6, duration: "2s 12d", rating: 8.6, status: "published", featured: true, description: "Orbitadagi stansiyada yuz bergan sirli hodisa va uni tushunishga urinish." },
    { id: 7, title: "THE FIRST CITY", genre: "Drama", year: 2026, type: "series", poster: 6, duration: "8 qism", rating: 8.3, status: "published", featured: false, description: "Birinchi shaharning qurilishi va uni yaratgan odamlar taqdiri." },
    { id: 8, title: "NORTH", genre: "Action", year: 2026, type: "series", poster: 1, duration: "10 qism", rating: 7.8, status: "published", featured: false, description: "Shimoliy chegarada xizmat qiluvchi guruhning og‘ir mavsumi." },
  ];

  const clone = (v) => JSON.parse(JSON.stringify(v));

  function safeGet(storage, key) {
    try { return storage.getItem(key); } catch (e) { return null; }
  }
  function safeSet(storage, key, value) {
    try { storage.setItem(key, value); return true; } catch (e) { return false; }
  }
  function safeRemove(storage, key) {
    try { storage.removeItem(key); } catch (e) { /* ignore */ }
  }

  /** Allow only http(s) image URLs. */
  function cleanUrl(url) {
    if (!url) return "";
    try {
      const u = new URL(String(url).trim());
      return u.protocol === "https:" || u.protocol === "http:" ? u.href : "";
    } catch (e) { return ""; }
  }

  function normalize(m, fallbackId) {
    const year = parseInt(m.year, 10);
    const rating = parseFloat(m.rating);
    const poster = parseInt(m.poster, 10);
    return {
      id: Number.isFinite(+m.id) ? +m.id : fallbackId,
      title: String(m.title || "").trim().slice(0, 80),
      genre: GENRES.includes(m.genre) ? m.genre : "Drama",
      year: Number.isFinite(year) ? Math.min(Math.max(year, 1900), 2100) : new Date().getFullYear(),
      type: m.type === "series" ? "series" : "movie",
      poster: poster >= 1 && poster <= 6 ? poster : 1,
      posterUrl: cleanUrl(m.posterUrl),
      duration: String(m.duration || "").trim().slice(0, 20),
      rating: Number.isFinite(rating) ? Math.min(Math.max(rating, 0), 10) : 0,
      status: m.status === "draft" ? "draft" : "published",
      featured: !!m.featured,
      description: String(m.description || "").trim().slice(0, 500),
    };
  }

  function load() {
    const raw = safeGet(localStorage, STORAGE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed.map((m, i) => normalize(m, i + 1)).filter((m) => m.title);
      } catch (e) { /* fall through to defaults */ }
    }
    return clone(DEFAULTS);
  }

  function save(list) {
    return safeSet(localStorage, STORAGE_KEY, JSON.stringify(list));
  }

  function reset() {
    safeRemove(localStorage, STORAGE_KEY);
    return clone(DEFAULTS);
  }

  function nextId(list) {
    return list.reduce((max, m) => Math.max(max, m.id), 0) + 1;
  }

  /* ---------- Auth ---------- */
  async function sha(text) {
    const data = new TextEncoder().encode("kinora::v1::" + text);
    const buf = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  function lockState() {
    try {
      const s = JSON.parse(safeGet(localStorage, LOCK_KEY) || "{}");
      return { attempts: s.attempts || 0, until: s.until || 0 };
    } catch (e) { return { attempts: 0, until: 0 }; }
  }

  function lockRemaining() {
    return Math.max(0, Math.ceil((lockState().until - Date.now()) / 1000));
  }

  async function adminLogin(username, password) {
    if (lockRemaining() > 0) return { ok: false, locked: lockRemaining() };
    if (!global.crypto || !crypto.subtle) return { ok: false, error: "Brauzer xavfsiz rejimni qo‘llamaydi (HTTPS yoki localhost kerak)." };
    const [u, p] = await Promise.all([sha(username.trim()), sha(password)]);
    if (u === ADMIN.user && p === ADMIN.pass) {
      safeRemove(localStorage, LOCK_KEY);
      safeSet(sessionStorage, SESSION_KEY, JSON.stringify({ at: Date.now() }));
      return { ok: true };
    }
    const st = lockState();
    const attempts = st.attempts + 1;
    const locked = attempts >= MAX_ATTEMPTS;
    safeSet(localStorage, LOCK_KEY, JSON.stringify({ attempts: locked ? 0 : attempts, until: locked ? Date.now() + LOCK_MS : 0 }));
    return { ok: false, left: locked ? 0 : MAX_ATTEMPTS - attempts, locked: locked ? LOCK_MS / 1000 : 0 };
  }

  function isAdmin() {
    try {
      const s = JSON.parse(safeGet(sessionStorage, SESSION_KEY) || "null");
      if (s && Date.now() - s.at < SESSION_TTL) return true;
    } catch (e) { /* ignore */ }
    safeRemove(sessionStorage, SESSION_KEY);
    return false;
  }

  function adminLogout() { safeRemove(sessionStorage, SESSION_KEY); }

  function esc(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  global.KinoraStore = {
    GENRES, GENRE_LABELS, load, save, reset, nextId, normalize, cleanUrl, esc,
    adminLogin, isAdmin, adminLogout, lockRemaining,
  };
})(window);
